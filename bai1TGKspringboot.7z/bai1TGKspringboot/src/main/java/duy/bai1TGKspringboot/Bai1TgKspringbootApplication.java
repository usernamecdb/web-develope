package duy.bai1TGKspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bai1TgKspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Bai1TgKspringbootApplication.class, args);
	}

}
